class Navigation {

}

export {
  Navigation
}