import { setter } from "src/core/store/utils";
import { create } from "zustand";
import { combine } from "zustand/middleware";

interface InterTabList {
  title: string;
  iconType: string;
  key: string;
  component?: () => JSX.Element;
}

const tabList: Array<InterTabList> = [
  {
    title: "待办事项",
    iconType: "bullet-list",
    key: "Home",
  },
  {
    title: "拍照",
    iconType: "camera",
    key: "History",
  },
  { title: "文件夹", iconType: "folder", key: "Mime" },
];

interface IHomeSate {
  active: number;
  tabList: Array<InterTabList>;
}
interface IHomeAction {
  setActive: (index: number | Function) => void;
}

const DEFAULT_TAB = 0; // 默认选中的tab 默认是0

const homeState = create(
  combine<IHomeSate, IHomeAction>(
    {
      active: DEFAULT_TAB,
      tabList: tabList,
    },
    (set) => ({
      setActive: setter("active")(set),
    })
  )
);

const useHome = () => {
  // 所有逻辑在这里聚合
  const { tabList, active, setActive } = homeState();

  const onActiveChange = (idex: number) => {
    setActive(idex);
  };

  return {
    active,
    tabList,
    onActiveChange,
  };
};

export { useHome };
