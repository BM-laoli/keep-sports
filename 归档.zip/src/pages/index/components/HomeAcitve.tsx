import { View,Text } from "@tarojs/components";
import { CSSProperties, useEffect, useState } from "react";

const HomeActive = () => {
  useEffect(()=>{
    console.log('初始化')
  },[])
    return (
      <View style={styles.homeActive}>
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        {/* <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View> 
        <View style={styles.viewBox}></View>  */}
      </View>
    )
}

const styles:{
  [key:string]: CSSProperties
} = {
    homeActive: {
      height: '100%', 
      // height:1024,
      // backgroundColor: 'royalblue'
      paddingTop:20
    },
    viewBox: {
      height:100,
      width:375,
      backgroundColor: 'skyblue',
      borderBottom: '4px solid #ccc'
    }
}
export {
  HomeActive
}