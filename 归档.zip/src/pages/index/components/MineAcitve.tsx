import { View,Text } from "@tarojs/components";
import { useState } from "react";

const MineActive = () => {
    return (
        <View>
        <Text>MineActive 内容区域2</Text>
      </View>
    )
}

export {
  MineActive
}