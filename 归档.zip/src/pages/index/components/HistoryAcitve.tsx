import { View,Text } from "@tarojs/components";
import { useState } from "react";


const HistoryActive = () => {
    return (
        <View className="HistoryActive">
        <Text>HistoryActive 内容区域2</Text>
      </View>
    )
}

export {
  HistoryActive
}